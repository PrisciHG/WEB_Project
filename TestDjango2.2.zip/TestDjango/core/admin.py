from django.contrib import admin

# Register your models here.
from .models import contacto

admin.site.register(contacto)